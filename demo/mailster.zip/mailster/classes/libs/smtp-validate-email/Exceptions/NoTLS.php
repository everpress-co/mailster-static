<?php

namespace SMTPValidateEmail\Exceptions;

class NoTLS extends Exception
{

}
