<?php

namespace SMTPValidateEmail\Exceptions;

class Timeout extends Exception
{

}
