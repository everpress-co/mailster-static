<?php

namespace SMTPValidateEmail\Exceptions;

class SendFailed extends Exception
{

}
