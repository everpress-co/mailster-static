<?php

namespace SMTPValidateEmail\Exceptions;

class NoMailFrom extends Exception
{

}
