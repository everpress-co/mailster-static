<?php

namespace SMTPValidateEmail\Exceptions;

class NoConnection extends Exception
{

}
