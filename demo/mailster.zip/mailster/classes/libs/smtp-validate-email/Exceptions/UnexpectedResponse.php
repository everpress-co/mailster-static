<?php

namespace SMTPValidateEmail\Exceptions;

class UnexpectedResponse extends Exception
{

}
