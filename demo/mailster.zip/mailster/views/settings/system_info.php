<p><?php esc_html_e( 'Run a System Test to get more info about issues with Mailster on your server.', 'mailster' ); ?></p>
<p><a class="button button-primary button-hero" href="<?php echo admin_url( 'admin.php?page=mailster_tests&autostart' ); ?>"><?php esc_html_e( 'Run System Test', 'mailster' ); ?></a>
</p>
