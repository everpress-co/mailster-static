<!-- wp:mailster/form-wrapper {"background":{"opacity":40,"fixed":false,"repeat":false,"size":"cover","fullscreen":false,"position":{"x":0.67,"y":0.45},"image":"https://static.mailster.co/forms/roasted-coffee.jpg"},"style":{"color":{"background":"#332b2b"},"spacing":{"padding":{"top":"4em","right":"4em","bottom":"4em","left":"4em"}}}} -->
    <form method="post" novalidate style="background-color:#332b2b;padding-top:4em;padding-right:4em;padding-bottom:4em;padding-left:4em" class="wp-block-mailster-form-wrapper mailster-block-form has-background has-background"><div class="mailster-block-form-inner"><!-- wp:spacer -->
<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"textAlign":"center","style":{"typography":{"fontStyle":"normal","fontWeight":"600","fontSize":"5rem"},"color":{"text":"#f4f4f4"}}} -->
<h2 class="wp-block-heading has-text-align-center has-text-color" style="color:#f4f4f4;font-size:5rem;font-style:normal;font-weight:600">Take 20%</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#f4f4f4"}}} -->
<p class="has-text-align-center has-text-color" style="color:#f4f4f4">Sign up for our email and save on your first order!</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:mailster/field-email {"align":"center","justify":"left","labelAlign":"center","inline":true,"style":{"width":60}} -->
<div class="wp-block-mailster-field-email mailster-wrapper mailster-wrapper-required mailster-wrapper-type-email mailster-wrapper-align-center mailster-wrapper-justify-left mailster-wrapper-label-align-center mailster-wrapper-inline mailster-wrapper-asterisk" style="width:60%"><input name="email" id="mailster-id-118aa2" type="email" aria-required="true" aria-label="Your Email address" spellcheck="false" required value="" class="input" autocomplete="email" placeholder=" "/><label for="mailster-id-118aa2" class="mailster-label">Your Email address</label></div>
<!-- /wp:mailster/field-email -->

<!-- wp:mailster/field-submit {"style":{"width":37}} -->
<div class="wp-block-mailster-field-submit mailster-wrapper mailster-wrapper-type-submit wp-block-button" style="width:37%"><input name="submit" id="mailster-id-7b79a3" type="submit" value="Get 20% now" class="wp-block-button__link submit-button"/></div>
<!-- /wp:mailster/field-submit -->

<!-- wp:spacer -->
<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div></form>
<!-- /wp:mailster/form-wrapper -->