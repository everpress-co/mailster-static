<!-- wp:mailster/form-wrapper {"css":{"general":".mailster-wrapper{\n    margin-bottom:1em;\n}\n"}} -->
<form method="post" novalidate class="wp-block-mailster-form-wrapper mailster-block-form"><div class="mailster-block-form-inner">

<!-- wp:mailster/field-firstname {"inline":true,"style":{"width":49}} -->
<div class="wp-block-mailster-field-firstname mailster-wrapper mailster-wrapper-type-text mailster-wrapper-inline" style="width:49%"><input name="firstname" id="mailster-id-2c4fa9" type="text" aria-required="false" aria-label="First Name" spellcheck="false" value="" class="input" autocomplete="given-name" placeholder=" "/><label for="mailster-id-2c4fa9" class="mailster-label">First Name</label></div>
<!-- /wp:mailster/field-firstname -->

<!-- wp:mailster/field-lastname {"inline":true,"style":{"width":49}} -->
<div class="wp-block-mailster-field-lastname mailster-wrapper mailster-wrapper-type-text mailster-wrapper-inline" style="width:49%"><input name="lastname" id="mailster-id-64ce15" type="text" aria-required="false" aria-label="Last Name" spellcheck="false" value="" class="input" autocomplete="family-name" placeholder=" "/><label for="mailster-id-64ce15" class="mailster-label">Last Name</label></div>
<!-- /wp:mailster/field-lastname -->

<!-- wp:mailster/field-email {"inline":true} -->
<div class="wp-block-mailster-field-email mailster-wrapper mailster-wrapper-required mailster-wrapper-type-email mailster-wrapper-inline mailster-wrapper-asterisk"><input name="email" id="mailster-id-4a142f" type="email" aria-required="true" aria-label="Email" spellcheck="false" required value="" class="input" autocomplete="email" placeholder=" "/><label for="mailster-id-4a142f" class="mailster-label">Email</label></div>
<!-- /wp:mailster/field-email -->

<!-- wp:mailster/field-submit {"align":"center"} -->
<div class="wp-block-mailster-field-submit mailster-wrapper mailster-wrapper-type-submit mailster-wrapper-align-center wp-block-button"><input name="submit" id="mailster-id-02e1d6" type="submit" value="Subscribe now!" class="wp-block-button__link submit-button"/></div>
<!-- /wp:mailster/field-submit --></div></form>
<!-- /wp:mailster/form-wrapper -->