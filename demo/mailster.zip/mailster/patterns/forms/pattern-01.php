<!-- wp:mailster/form-wrapper {"css":{"general":".input, .submit-button{\n\theight:66px;\n}\n.mailster-wrapper{\n    margin:0 !important;\n}\n","tablet":"","mobile":""},"style":{"borderRadius":"0px","borderWidth":"0px"}} -->
<form method="post" novalidate class="wp-block-mailster-form-wrapper mailster-block-form"><div class="mailster-block-form-inner">
    
<!-- wp:mailster/field-email {"inline":true,"style":{"width":60}} -->
<div class="wp-block-mailster-field-email mailster-wrapper mailster-wrapper-required mailster-wrapper-type-email mailster-wrapper-inline mailster-wrapper-asterisk" style="width:60%"><input name="email" id="mailster-id-e9bcf9" type="email" aria-required="true" aria-label="Email" spellcheck="false" required value="" class="input" autocomplete="email" placeholder=" "/><label for="mailster-id-e9bcf9" class="mailster-label">Email</label></div>
<!-- /wp:mailster/field-email -->

<!-- wp:mailster/field-submit {"style":{"width":40,"borderRadius":"0px","borderWidth":"0px"}} -->
<div class="wp-block-mailster-field-submit mailster-wrapper mailster-wrapper-type-submit wp-block-button" style="width:40%"><input name="submit" id="mailster-id-3b9dc6" type="submit" style="border-width:0px;border-radius:0px" value="Subscribe" class="wp-block-button__link submit-button"/></div>
<!-- /wp:mailster/field-submit --></div></form>
<!-- /wp:mailster/form-wrapper -->