jQuery(document).ready(function ($) {
	'use strict';

	setInterval(function () {
		getPlayers();
	}, 3000);

	getPlayers();

	function getPlayers() {
		var post_id = jQuery('#post_ID').val();
		if (!post_id) return;

		wp.apiFetch({
			path: 'bingo/v1/players/' + post_id,
			method: 'GET',
		})
			.then((data) => {
				document.querySelector('.player-table').innerHTML = data.table;
				document.querySelector('.player-count').innerHTML = data.count;
				return Promise.reject(data);
			})
			.then((response) => {})
			.catch((error) => {});
	}

	$('.start').on('click', function (event) {
		if (confirm(this.dataset.msg)) {
			$('#bingo_action').val('start');
			return true;
		} else {
			return false;
		}
	});
	$('.reset').on('click', function (event) {
		if (confirm(this.dataset.msg)) {
			$('#bingo_action').val('reset');
			return true;
		} else {
			return false;
		}
	});
	$('.draw').on('click', function (event) {
		$('#bingo_action').val('draw');
		return true;
	});
	$('.stop').on('click', function (event) {
		if (confirm(this.dataset.msg)) {
			$('#bingo_action').val('stop');
			return true;
		} else {
			return false;
		}
	});
});
