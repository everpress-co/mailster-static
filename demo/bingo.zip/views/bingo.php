<?php

$post_id = $blockattributes['id'];
if ( $can_play = current_user_can( 'read' ) ) {
	$args['classes'][] = 'can-play';
} else {
	$args['classes'][] = 'can-not-play';
}

if ( 'numbers' === get_post_meta( $post_id, 'bingo_type', true ) ) {
	$args['classes'][] = 'is-numbers';
}

?>

<?php
	$freecell = true;
	$k        = 0;
?>

<div data-id="<?php echo esc_attr( $post_id ); ?>" class="<?php echo implode( ' ', $args['classes'] ); ?>">

	<header class="bingo-header">
			</header>

	<div class="bingo-fields">
		<div class="bingo-cell bingo-title">B</div>
		<div class="bingo-cell bingo-title">I</div>
		<div class="bingo-cell bingo-title">N</div>
		<div class="bingo-cell bingo-title">G</div>
		<div class="bingo-cell bingo-title">O</div>
	<?php for ( $i = 0; $i < 25; $i++ ) : ?>
		<?php
		if ( ! ( $i % 5 ) ) {
			$k++;
		}
		$letter = substr( 'bingo', $i % 5, 1 );

		?>
		<div class="bingo-cell bingo-cell-value bingo-cell-<?php echo esc_attr( $letter . $k ); ?>"
			data-field="<?php echo esc_attr( $letter . $k ); ?>"
			data-cell="<?php echo esc_attr( $i ); ?>"
			data-letter="<?php echo esc_attr( $letter ); ?>">
			<div class="bingo-text" data-delay="<?php echo esc_attr( $i * 100 ); ?>"></div>
		</div>
	<?php endfor; ?>
	</div>

	<div class="bingo-buttons">
		<p class="info-join" data-wait="<?php esc_attr_e( 'Please wait until the session starts.', 'bingo' ); ?>"><?php esc_html_e( 'Join the game here.', 'bingo' ); ?></p>
		<p class="info-join"><a class="wp-block-button__link btn-join"><?php esc_html_e( 'Get Bingo Card', 'bingo' ); ?></a></p>
		<p class="info-login"><?php esc_html_e( 'Please login to join the game.', 'bingo' ); ?></p>
		<p class="info-login"><a href="<?php echo wp_login_url( remove_query_arg( 'foo' ) ); ?>" class="wp-block-button__link btn-login"><?php esc_html_e( 'Login', 'bingo' ); ?></a></p>
	</div>

	<img src="<?php echo plugin_dir_url( BINGO_PLUGIN_FILE ) ?>assets/logotype.png" class="bingo-logotype">

</div>
	
