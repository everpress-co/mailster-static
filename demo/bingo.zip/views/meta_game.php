<?php
namespace EverPress;

	$status = get_post_meta( get_the_ID(), 'bingo_status', true );
	$terms  = Bingo::get_drewn_terms( get_the_ID(), true );

?>
<input name="bingo_action" id="bingo_action" type="hidden">
<table class="form-table" role="presentation">
<tbody><tr>
<th scope="row"></th>
<td><fieldset><legend class="screen-reader-text"><span><?php esc_html_e( 'Start/Stop Game', 'bingo' ); ?></span></legend>
<?php if ( $status !== 'started' ) : ?>
	<button class="button button-hero button-primary start" name="start_bingo" data-msg="<?php esc_attr_e( 'Do you really like to start this game?', 'bingo' ); ?>">Start</button>	
	<button class="button button-hero reset" name="reset_bingo" data-msg="<?php esc_attr_e( 'Do you really like to reset this game?', 'bingo' ); ?>"><?php esc_html_e( 'Reset Game', 'bingo' ); ?></button>

<?php else : ?>
	<button class="button button-hero stop" name="stop_bingo" data-msg="<?php esc_attr_e( 'Stop this game?', 'bingo' ); ?>"><?php esc_html_e( 'Stop', 'bingo' ); ?></button>
<?php endif; ?>
</fieldset>
</td>
</tr>

<?php if ( $status === 'started' ) : ?>
<tr>
<th scope="row"></th>
<td><h3 class="current-term"><?php echo print_r( Bingo::get_last_draw( get_the_ID() ), true ); ?></h3>
	<button class="button button-hero button-primary draw" name="draw_bingo"><?php esc_html_e( 'Draw', 'bingo' ); ?></button></td>
</tr>
<?php endif; ?>

<tr>
<th scope="row"><?php esc_html_e( 'Players', 'bingo' ); ?></th>
<td><fieldset>
	<legend class="screen-reader-text"><span><?php esc_html_e( 'Players', 'bingo' ); ?></span></legend>
	</fieldset>
	<p>
		<?php printf( 'Currently %s player(s) are in this match.', '<span class="player-count">0</span>' ); ?>
	</p>
<table class="wp-list-table widefat fixed striped player-table"></table>
</td>
</tr>

</tbody></table>
