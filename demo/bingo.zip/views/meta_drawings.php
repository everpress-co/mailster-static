<?php
namespace EverPress;

$terms = Bingo::get_drewn_terms( get_the_ID(), true );

?>


<?php if ( $terms ) : ?>
	<table class="wp-list-table widefat fixed striped">
	<?php $term_count = count( $terms ); ?>
	<?php foreach ( $terms as $i => $term ) : ?>
		<tr>
			<td width="20"><?php echo ( $term_count - $i ); ?></td>
			<td width="20"><?php echo Bingo::get_letter_of_term( get_the_ID(), $term ); ?></td>
			<td><?php echo esc_html( $term ); ?></td>
		</tr>
	<?php endforeach; ?>
</table>
<?php else:  ?>
	<p><?php esc_html_e( 'No drawings yet.', 'bingo' ); ?></p>
<?php endif; ?>
