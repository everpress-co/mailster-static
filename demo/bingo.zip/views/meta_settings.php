<?php

namespace EverPress;

$post_id = get_the_ID();
$type    = get_post_meta( $post_id, 'bingo_type', true );
if ( ! $type ) {
	$type = 'words';
}

?>

<table class="form-table" role="presentation">

<tr>
	<th scope="row"><?php esc_html_e( 'Bingo Type', 'bingo' ); ?></th>
	<td><fieldset><legend class="screen-reader-text"><span><?php esc_html_e( 'Bingo Type', 'bingo' ); ?></span></legend>
	<p>
		<label><input name="bingo_type" type="radio" value="numbers"<?php checked( $type, 'numbers' ); ?>> <?php esc_html_e( 'Numbers (1-75)', 'bingo' ); ?></label><br>
		<label><input name="bingo_type" type="radio" value="words" <?php checked( $type, 'words' ); ?>> <?php esc_html_e( 'Words', 'bingo' ); ?></label>
	</p>
	<p class="description">
		<?php esc_html_e( 'Changing the Type will also reset the current game!', 'bingo' ); ?>
	</p>
</fieldset></td>
</tr>
</table>
