<?php

namespace EverPress;

/**
 * Plugin Name:       Bingo
 * Description:       This is a bingo game
 * Requires at least: 5.9
 * Requires PHP:      7.0
 * Version:           1.0.1
 * Author:            EverPress
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       bingo
 * Update URI:        false
 */


defined( 'ABSPATH' ) || exit;

if ( ! defined( 'BINGO_PLUGIN_FILE' ) ) {
	define( 'BINGO_PLUGIN_FILE', __FILE__ );
}

if ( ! class_exists( 'EverPress\Bingo' ) ) {
	include_once 'includes/class-bingo.php';
}

add_action( 'plugins_loaded', array( 'EverPress\Bingo', 'get_instance' ) );

