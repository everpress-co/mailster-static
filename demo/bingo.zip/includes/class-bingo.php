<?php

namespace EverPress;

class Bingo {

	private static $instance = null;

	private function __construct() {

		\register_activation_hook( BINGO_PLUGIN_FILE, 'flush_rewrite_rules' );
		\register_deactivation_hook( BINGO_PLUGIN_FILE, 'flush_rewrite_rules' );

		\add_action( 'init', array( $this, 'create_block_bingo_block_init' ) );
		\add_action( 'init', array( $this, 'register_post_type' ) );
		\add_action( 'rest_api_init', array( &$this, 'rest_api_init' ) );

		\add_action( 'the_content', array( $this, 'the_content' ) );

		\add_action( 'save_post_bingo', array( $this, 'save_meta_data' ), 1, 100 );
		\add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		\add_action( 'wp_enqueue_scripts', array( $this, 'wp_enqueue_scripts' ) );

	}

	public static function get_instance() {
		if ( self::$instance == null ) {
			self::$instance = new Bingo();
		}

		return self::$instance;
	}

	public function create_block_bingo_block_init() {
		\register_block_type( dirname( BINGO_PLUGIN_FILE ) . '/build', array( 'render_callback' => array( $this, 'render_bingo' ) ) );
	}

	// Register Custom Post Type
	public function register_post_type() {

		$labels = array(
			'name'                  => _x( 'Bingos', 'Post Type General Name', 'bingo' ),
			'singular_name'         => _x( 'Post BingoType', 'Post Type Singular Name', 'bingo' ),
			'menu_name'             => __( 'Bingo', 'bingo' ),
			'name_admin_bar'        => __( 'Bingo', 'bingo' ),
			'archives'              => __( 'Bingo Archive', 'bingo' ),
			'attributes'            => __( 'Bingo Attributes', 'bingo' ),
			'parent_item_colon'     => __( 'Parent Bingo', 'bingo' ),
			'all_items'             => __( 'All Bingos', 'bingo' ),
			'add_new_item'          => __( 'Add New Bingo', 'bingo' ),
			'add_new'               => __( 'Add New', 'bingo' ),
			'new_item'              => __( 'New Bingo', 'bingo' ),
			'edit_item'             => __( 'Edit Bingo', 'bingo' ),
			'update_item'           => __( 'Update Bingo', 'bingo' ),
			'view_item'             => __( 'View Bingo', 'bingo' ),
			'view_items'            => __( 'View Bingos', 'bingo' ),
			'search_items'          => __( 'Search Bingos', 'bingo' ),
			'not_found'             => __( 'Not found', 'bingo' ),
			'not_found_in_trash'    => __( 'Not found in Trash', 'bingo' ),
			'featured_image'        => __( 'Featured Image', 'bingo' ),
			'set_featured_image'    => __( 'Set featured image', 'bingo' ),
			'remove_featured_image' => __( 'Remove featured image', 'bingo' ),
			'use_featured_image'    => __( 'Use as featured image', 'bingo' ),
			'insert_into_item'      => __( 'Insert into Bingo', 'bingo' ),
			'uploaded_to_this_item' => __( 'Uploaded to this Bingo', 'bingo' ),
			'items_list'            => __( 'List of Bingos', 'bingo' ),
			'items_list_navigation' => __( 'Bingos list navigation', 'bingo' ),
			'filter_items_list'     => __( 'Filter Bingos', 'bingo' ),
		);
		$args   = array(
			'label'                => __( 'Post BingoType', 'bingo' ),
			'description'          => __( 'A Bingo', 'bingo' ),
			'labels'               => $labels,
			'supports'             => array( 'title', 'comments' ),
			'hierarchical'         => false,
			'public'               => true,
			'show_ui'              => true,
			'show_in_menu'         => true,
			'menu_position'        => 20,
			'menu_icon'            => 'dashicons-forms',
			'show_in_admin_bar'    => true,
			'show_in_nav_menus'    => true,
			'can_export'           => false,
			'has_archive'          => true,
			'exclude_from_search'  => true,
			'publicly_queryable'   => true,
			'capability_type'      => 'post',
			'show_in_rest'         => true,
			'register_meta_box_cb' => array( $this, 'register_meta_box' ),
		);

		\register_post_type( 'bingo', $args );

	}

	public function enqueue_scripts() {

		if ( get_post_type() !== 'bingo' ) {
			return;
		}

		\wp_enqueue_style( 'bingo-admin-style', plugin_dir_url( BINGO_PLUGIN_FILE ) . 'assets/admin-style.css', array(), '1.0.1' );
		\wp_enqueue_script( 'bingo-admin-script', plugin_dir_url( BINGO_PLUGIN_FILE ) . 'assets/admin-script.js', array( 'jquery', 'wp-api-fetch' ), '1.0.1', true );

	}

	public function wp_enqueue_scripts() {

		\wp_register_style( 'bingo-google-font', 'https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,500i,700,700i|Roboto:300,300i,400,400i,500,500i,700,700i&subset=latin-ext&display=fallback' );

	}

	public function register_meta_box() {
		\add_meta_box( 'bingo_game', __( 'Bingo Game', 'bingo' ), array( $this, 'meta_box_game' ), 'bingo', 'normal', 'high' );
		\add_meta_box( 'bingo_settings', __( 'Bingo Details', 'bingo' ), array( $this, 'meta_box_setting' ), 'bingo', 'normal', 'high' );
		\add_meta_box( 'bingo_drawings', __( 'Drawings', 'bingo' ), array( $this, 'meta_box_drawings' ), 'bingo', 'side', 'default' );
	}

	public function meta_box_game() {
		include dirname( BINGO_PLUGIN_FILE ) . '/views/meta_game.php';
	}

	public function meta_box_setting() {
		include dirname( BINGO_PLUGIN_FILE ) . '/views/meta_settings.php';
	}

	public function meta_box_drawings() {
		include dirname( BINGO_PLUGIN_FILE ) . '/views/meta_drawings.php';
	}

	public function save_meta_data( $post_id ) {

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( $parent_id = wp_is_post_revision( $post_id ) ) {
			$post_id = $parent_id;
		}

		if ( isset( $_POST['bingo_type'] ) ) {
			if ( update_post_meta( $post_id, 'bingo_type', sanitize_key( $_POST['bingo_type'] ) ) ) {
				self::reset( $post_id );
			}
		}
		if ( isset( $_POST['bingo_action'] ) ) {
			switch ( $_POST['bingo_action'] ) {
				case 'start':
					update_post_meta( $post_id, 'bingo_status', 'started' );
					break;
				case 'stop':
					update_post_meta( $post_id, 'bingo_status', 'stopped' );
					break;
				case 'reset':
					self::reset( $post_id );
					break;
				case 'draw':
					self::draw( $post_id );
					break;
			}
		}

	}

	public function render_bingo( $args, $content, \WP_Block $block ) {

		$blockattributes = $block->attributes;

		$args = wp_parse_args(
			$args,
			array(
				'classes' => array( 'wp-block-everpress-bingo bingo' ),
			)
		);
		if ( isset( $blockattributes['align'] ) ) {
			$args['classes'][] = 'align' . $blockattributes['align'];
		}

		wp_enqueue_script( 'everpress-bingo-view-script' );
		wp_enqueue_style( 'bingo-google-font' );

		ob_start();
		include dirname( BINGO_PLUGIN_FILE ) . '/views/bingo.php';
		$bingo = ob_get_contents();

		ob_end_clean();

		return $bingo;

	}

	public function the_content( $content ) {

		if ( 'bingo' == get_post_type() && is_single() ) {
			$content .= do_blocks( '<!-- wp:everpress/bingo  {"id": ' . get_the_ID() . ', "align":"wide"} -->' );
		}
		return $content;

	}

	public static function join( $bingo_id, $user_id = null ) {

		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		if ( ! $user_id ) {
			return false;
		}

		$term_ids = self::get_terms_ids_for_user( $bingo_id, $user_id );

		return $term_ids;

	}

	public static function draw( $bingo_id ) {

		$drewn = self::get_drewn_terms( $bingo_id );
		$terms = self::get_terms_chunks( $bingo_id );

		$total_terms = array_sum( array_map( 'count', $terms ) );

		if ( count( $drewn ) >= $total_terms ) {
			return false;
		}

		do {
			$c    = rand( 0, 4 );
			$col  = $terms[ $c ];
			$drew = $col[ array_rand( $col ) ];
		} while ( in_array( $drew, $drewn ) );

		$drewn[] = $drew;

		update_post_meta( $bingo_id, 'bingo_drewn', $drewn );

		return $drew;

	}

	public static function get_last_draw( $bingo_id ) {

		$drewn       = self::get_drewn_terms( $bingo_id );
		$terms       = self::get_terms_chunks( $bingo_id );
		$total_terms = array_sum( array_map( 'count', $terms ) );

		if ( count( $drewn ) >= $total_terms ) {
			return __( 'All terms have been drawn!', 'bingo' );
		}

		$last = array_pop( $drewn );

		$letter = self::get_letter_of_term( $bingo_id, $last );
		if ( false === $letter ) {
			return false;
		}

		return $letter . ' - ' . $last;

	}

	public static function get_letter_of_term( $bingo_id, $term ) {
		$chunks = self::get_terms_chunks( $bingo_id );

		foreach ( $chunks as $chunk_key => $chunk ) {
			if ( ( $key = array_search( $term, $chunk ) ) !== false ) {
				$letter = 'BINGO'[ $chunk_key ];
				return $letter;
			}
		}

		return false;

	}

	public static function get_drewn_terms( $bingo_id, $reverse = false ) {

		$terms = get_post_meta( $bingo_id, 'bingo_drewn', true );

		if ( ! $terms ) {
			$terms = array();
		}

		if ( $reverse ) {
			$terms = array_reverse( $terms );
		}

		return ( $terms );

	}

	public static function get_terms_chunks( $bingo_id ) {
		$terms = array();

		$all_terms    = self::get_terms_from_bingo( $bingo_id );
		$chunksize    = floor( count( $all_terms ) / 5 );
		$terms_chunks = array_chunk( $all_terms, $chunksize );

		return $terms_chunks;

	}

	public static function get_terms_ids_for_user( $bingo_id, $user_id ) {

		$terms = get_usermeta( $user_id, 'bingo_terms_' . $bingo_id );
		if ( ! $terms ) {

			$terms = array();

			$terms_chunks = self::get_terms_chunks( $bingo_id );

			$k = 0;

			for ( $i = 0; $i < 25; $i++ ) :

				$chunk = ( $i % 5 );
				shuffle( $terms_chunks[ $chunk ] );
				$term = array_pop( $terms_chunks[ $chunk ] );

				$letter = substr( 'bingo', $chunk, 1 );
				if ( ! $chunk ) {
					$k++;
				}
				$terms[ $letter . $k ] = $term;

			endfor;

			$terms['n3'] = '<img src="' . plugin_dir_url( BINGO_PLUGIN_FILE ) . 'assets/logo.png">';

			update_usermeta( $user_id, 'bingo_terms_' . $bingo_id, $terms );

		}

		return $terms;

	}


	public static function get_terms_from_bingo( $bingo_id ) {

		$type = get_post_meta( $bingo_id, 'bingo_type', true );

		if ( $type === 'numbers' ) {

			$from = 1;
			$to   = 75;

			$terms = range( $from, $to );

		} else {

			include dirname( BINGO_PLUGIN_FILE ) . '/includes/terms.php';

		}

		return $terms;

	}


	public static function wait( $bingo_id ) {

		$status = get_post_meta( $bingo_id, 'bingo_status', true );

		if ( 'started' === $status ) {
			return false;
		}

		return true;

	}

	public static function reset( $bingo_id ) {

		delete_post_meta( $bingo_id, 'bingo_status' );
		delete_post_meta( $bingo_id, 'bingo_drewn' );

		global $wpdb;

		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->usermeta} WHERE meta_key = %s", 'bingo_terms_' . intval( $bingo_id ) ) );
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->usermeta} WHERE meta_key = %s", 'bingo_logins_' . intval( $bingo_id ) ) );

		return false;

	}

	public static function login( $bingo_id, $field, $user_id = null ) {

		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		$logins = get_usermeta( $user_id, 'bingo_logins_' . $bingo_id );
		if ( ! $logins ) {
			$logins = array();
		}

		$term_ids = self::get_terms_ids_for_user( $bingo_id, $user_id );

		$user_term = $term_ids[ $field ];
		$drewn     = self::get_drewn_terms( $bingo_id );

		if ( in_array( $user_term, $drewn ) || $field === 'n3' ) {
			$logins[] = $field;
		}

		$logins = array_unique( $logins );

		update_usermeta( $user_id, 'bingo_logins_' . $bingo_id, $logins );

		return $logins;

	}

	public static function logout( $bingo_id, $field, $user_id = null ) {

		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		$logins = get_usermeta( $user_id, 'bingo_logins_' . $bingo_id );

		if ( ! $logins ) {
			return array();
		}

		if ( ( $key = array_search( $field, $logins ) ) !== false ) {
			unset( $logins[ $key ] );
		}

		$logins = array_unique( array_values( $logins ) );

		update_usermeta( $user_id, 'bingo_logins_' . $bingo_id, $logins );

		return $logins;

	}


	public static function is_login( $bingo_id, $user_id = null ) {

		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		$logins = get_usermeta( $user_id, 'bingo_logins_' . $bingo_id );
		if ( ! $logins ) {
			return false;
		}

		return $logins;
	}


	public static function is_bingo( $bingo_id, $user_id = null ) {

		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		$terms = get_usermeta( $user_id, 'bingo_terms_' . $bingo_id );
		if ( ! $terms ) {
			return false;
		}
		$logins = get_usermeta( $user_id, 'bingo_logins_' . $bingo_id );
		if ( ! $logins ) {
			return false;
		}

		$bingo_rows = array();

		// vertical rows
		// foreach ( array( 'b', 'i', 'n', 'g', 'o' ) as $l ) {
		// $r = preg_grep( '/^' . $l . '/', $logins );
		// if ( count( $r ) == 5 ) {
		// $bingo_rows += $r;
		// }
		// }
		// horizontal rows
		for ( $i = 1; $i <= 5; $i++ ) {
			$r = preg_grep( '/' . $i . '$/', $logins );
			if ( count( $r ) == 5 ) {
				$bingo_rows += $r;
			}
		}

		// diagonal lt br
		$r = preg_grep( '/^(b1|i2|n3|g4|o5)$/', $logins );
		if ( count( $r ) == 5 ) {
			$bingo_rows += $r;
		}

		// diagonal lb rt
		$r = preg_grep( '/^(b5|i4|n3|g2|o1)$/', $logins );
		if ( count( $r ) == 5 ) {
			$bingo_rows += $r;
		}

		return ! empty( $bingo_rows ) ? array_values( $bingo_rows ) : false;

	}

	public function rest_api_init() {

		require dirname( BINGO_PLUGIN_FILE ) . '/includes/class-rest.php';

		$controller = new Bingo_REST_Form_Controller();
		$controller->register_routes();

	}

}
