<?php

namespace EverPress;

/**
 * Class Bingo_REST_Form_Controller
 */
class Bingo_REST_Form_Controller extends \WP_REST_Controller {
	/**
	 * The namespace.
	 *
	 * @var string
	 */
	protected $namespace;

	public function __construct() {

		$this->namespace = 'bingo/v1';
	}

	/**
	 * Register the routes for the objects of the controller.
	 */
	public function register_routes() {

		register_rest_route(
			$this->namespace,
			'/join',
			array(

				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'join' ),
					'permission_callback' => function() {
						return current_user_can( 'read' );
					},
				),
				'schema' => null,

			)
		);

		register_rest_route(
			$this->namespace,
			'/login',
			array(

				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'login' ),
					'permission_callback' => function() {
						return current_user_can( 'read' );
					},
				),
				'schema' => null,

			)
		);
		register_rest_route(
			$this->namespace,
			'/logout',
			array(

				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'logout' ),
					'permission_callback' => function() {
						return current_user_can( 'read' );
					},
				),
				'schema' => null,

			)
		);

		register_rest_route(
			$this->namespace,
			'/players/(?P<id>[\d]+)',
			array(

				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_players' ),
					'permission_callback' => function() {
						return current_user_can( 'edit_others_pages' );
					},
				),
				'schema' => null,

			)
		);

	}


	public function join( $request ) {

		$params = $request->get_url_params();

		$id = $request->get_param( 'id' );

		return rest_ensure_response(
			array(
				'wait'   => Bingo::wait( $id ),
				'result' => Bingo::join( $id ),
				'login'  => Bingo::is_login( $id ),
				'bingo'  => Bingo::is_bingo( $id ),

			)
		);
	}


	public function login( $request ) {

		$params = $request->get_url_params();

		$id    = $request->get_param( 'id' );
		$field = $request->get_param( 'field' );

		return rest_ensure_response(
			array(
				'result' => Bingo::login( $id, $field ),
				'login'  => Bingo::is_login( $id ),
				'bingo'  => Bingo::is_bingo( $id ),

			)
		);
	}


	public function logout( $request ) {

		$params = $request->get_url_params();

		$id    = $request->get_param( 'id' );
		$field = $request->get_param( 'field' );

		return rest_ensure_response(
			array(
				'result' => Bingo::logout( $id, $field ),
				'login'  => Bingo::is_login( $id ),
				'bingo'  => Bingo::is_bingo( $id ),

			)
		);
	}


	public function get_players( $request ) {

		$params = $request->get_url_params();

		$id = isset( $params['id'] ) ? (int) $params['id'] : null;

		global $wpdb;

		$sql = "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s ORDER BY user_id";
		$sql = $wpdb->prepare( $sql, 'bingo_terms_' . $id );

		$table  = array();
		$bingos = array();

		if ( $result = $wpdb->get_col( $sql ) ) {

			foreach ( $result as $user_id ) {
				$user     = get_user_by( 'id', $user_id );
				$is_bingo = Bingo::is_bingo( $id, $user_id );
				$is_login = Bingo::is_login( $id, $user_id );

				if ( $is_bingo ) {
					$last_action                       = get_user_meta( $user_id, 'bingo_last_action_' . $id, true );
					$bingos[ $last_action . $user_id ] = $user;
				}

				$bingo = '';
				$html  = '';
				$k     = 0;

				for ( $i = 0; $i < 25; $i++ ) :
					if ( ! ( $i % 5 ) ) {
						$k++;
					}
					$classes = array( 'bingo-cell bingo-cell' );
					$letter  = substr( 'bingo', $i % 5, 1 ) . $k;

					$classes[] = 'bingo-cell-' . $letter;
					if ( $is_login && in_array( $letter, $is_login ) ) {
						$classes[] = 'is-login';
					}
					if ( $is_bingo && in_array( $letter, $is_bingo ) ) {
						$classes[] = 'is-bingo';
					}

					$bingo .= '
					<div class="' . implode( ' ', $classes ) . '"
						data-field="' . esc_attr( $letter ) . '"
						data-cell="' . esc_attr( $i ) . '"
						data-letter="' . esc_attr( $letter ) . '">
						<div class="bingo-text" data-delay="' . esc_attr( $i * 100 ) . '"></div>
					</div>';

				endfor;

				$html .= '<tr class="' . ( $is_bingo ? 'has-bingo' : '' ) . '">';
				$html .= '<td width="50">' . esc_attr( $user->ID ) . '</td>';
				$html .= '<td>';

				$html .= '<a href="' . admin_url( 'user-edit.php?user_id=' . $user->ID ) . '">' . esc_html( $user->first_name . ' ' . $user->last_name ) . '</a>';
				if ( $is_bingo ) {
					$html .= ' <br><strong>BINGO!</strong> ';
				} 
				$html .= '</td>';
				$html .= '<td width="100">';
				$html .= '<div class="bingo"><div class="bingo-fields">' . $bingo . '</div></div>';
				$html .= '</td>';
				$html .= '</tr>';

				if ( $is_bingo ) {
					array_unshift( $table, $html );
				} else {
					$table[] = $html;
				}
			}
		}

		// Return all of our comment response data.
		return rest_ensure_response(
			array(
				'bingos' => $bingos,
				'table'  => implode( '', $table ),
				'count'  => count( $result ),
			)
		);
	}

}
