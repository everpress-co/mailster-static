<!-- wp:mailster/form-wrapper {"background":{"opacity":20,"fixed":false,"repeat":false,"size":"cover","image":"https://static.mailster.co/forms/forest-in-winter.jpg","position":{"x":0.5,"y":0.5},"fullscreen":false},"css":{"general":".mailster-wrapper{\n    margin-top:1em;\n\tmargin-bottom:0.5em;\n}\n","tablet":"","mobile":""},"style":{"spacing":{"padding":{"top":"2em","right":"2em","bottom":"2em","left":"2em"}},"color":{"gradient":"radial-gradient( circle farthest-corner at 10% 20%,  rgba(255,94,247,1) 17.8%, rgba(2,245,255,1) 100.2% )"},"labelColor":"#000000","backgroundColor":"#ffffff"},"textColor":"white"} -->
    <form method="post" novalidate style="background:radial-gradient( circle farthest-corner at 10% 20%,  rgba(255,94,247,1) 17.8%, rgba(2,245,255,1) 100.2% );padding-top:2em;padding-right:2em;padding-bottom:2em;padding-left:2em" class="wp-block-mailster-form-wrapper mailster-block-form has-white-color has-text-color has-background has-white-color has-text-color has-background"><div class="mailster-block-form-inner"><!-- wp:heading {"textAlign":"left","align":"full","style":{"typography":{"fontStyle":"normal","fontWeight":"900"},"color":{"text":"#ffffff"}}} -->
<h2 class="wp-block-heading alignfull has-text-align-left has-text-color" style="color:#ffffff;font-style:normal;font-weight:900">Subscribe to our Newsletter!</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"color":{"text":"#ffffff"}}} -->
<p class="has-text-color" style="color:#ffffff">Stay up to date with the latest news and relevant updates from us.</p>
<!-- /wp:paragraph -->

<!-- wp:mailster/field-email {"inline":true} -->
<div class="wp-block-mailster-field-email mailster-wrapper mailster-wrapper-required mailster-wrapper-type-email mailster-wrapper-inline mailster-wrapper-asterisk"><input name="email" id="mailster-id-ec3db6" type="email" aria-required="true" aria-label="Enter your email address" spellcheck="false" required value="" class="input" autocomplete="email" placeholder=" "/><label for="mailster-id-ec3db6" class="mailster-label">Enter your email address</label></div>
<!-- /wp:mailster/field-email -->

<!-- wp:mailster/field-submit {"style":{"width":33}} -->
<div class="wp-block-mailster-field-submit mailster-wrapper mailster-wrapper-type-submit wp-block-button" style="width:33%"><input name="submit" id="mailster-id-89dca5" type="submit" value="Subscribe" class="wp-block-button__link submit-button"/></div>
<!-- /wp:mailster/field-submit --></div></form>
<!-- /wp:mailster/form-wrapper -->